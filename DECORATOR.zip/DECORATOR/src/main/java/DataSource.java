/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author FATEC ZONA LESTE
 */
// Interface que define operações para fontes de dados.
interface DataSource {
    void writeData(String data);
    String readData();
}
