/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author FATEC ZONA LESTE
 */
// Implementação concreta de uma fonte de dados de arquivo.
public class FileDataSource implements DataSource {
    private String filename;

    // Construtor que recebe o nome do arquivo.
    public FileDataSource(String filename) {
        this.filename = filename;
    }

    @Override
    public void writeData(String data) {
        System.out.println("Writing data to file: " + filename);
        // Aqui você poderia implementar a lógica real de escrita.
    }

    @Override
    public String readData() {
        System.out.println("Reading data from file: " + filename);
        // Aqui você poderia implementar a lógica real de leitura.
        return "data from file";
    }
}
