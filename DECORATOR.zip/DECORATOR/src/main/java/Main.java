/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author FATEC ZONA LESTE
 */
public class Main {
    public static void main(String[] args) {
        // Exemplo simples de uso com decoradores.
        String salaryRecords = "Salary data";

        // Criando um FileDataSource simples.
        DataSource source = new FileDataSource("somefile.dat");
        source.writeData(salaryRecords);

        // Adicionando compressão.
        source = new CompressionDecorator(source);
        source.writeData(salaryRecords);

        // Adicionando criptografia.
        source = new EncryptionDecorator(source);
        source.writeData(salaryRecords);

        // Lendo os dados criptografados e comprimidos.
        String result = source.readData();
        System.out.println("Final result: " + result);

        // Configuração em tempo de execução.
        ApplicationConfigurator configurator = new ApplicationConfigurator();
        configurator.configurationExample(true, true);
    }
}

