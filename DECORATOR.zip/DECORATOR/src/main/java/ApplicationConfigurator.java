/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author FATEC ZONA LESTE
 */
// Configura decoradores em tempo de execução com base no ambiente.
public class ApplicationConfigurator {

    public void configurationExample(boolean enabledEncryption, boolean enabledCompression) {
        DataSource source = new FileDataSource("salary.dat");

        if (enabledEncryption) {
            source = new EncryptionDecorator(source);
        }
        if (enabledCompression) {
            source = new CompressionDecorator(source);
        }

        SalaryManager manager = new SalaryManager(source);
        manager.save("Salary data");

        String loadedData = manager.load();
        System.out.println("Loaded data: " + loadedData);
    }
}
