/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author FATEC ZONA LESTE
 */
// Decorador concreto para criptografia de dados.
public class EncryptionDecorator extends DataSourceDecorator {

    public EncryptionDecorator(DataSource source) {
        super(source);
    }

    @Override
    public void writeData(String data) {
        String encryptedData = encrypt(data);
        wrappee.writeData(encryptedData);
    }

    @Override
    public String readData() {
        String data = wrappee.readData();
        return decrypt(data);
    }

    private String encrypt(String data) {
        System.out.println("Encrypting data...");
        return "encrypted(" + data + ")";
    }

    private String decrypt(String data) {
        System.out.println("Decrypting data...");
        return data.replace("encrypted(", "").replace(")", "");
    }
}
