/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author FATEC ZONA LESTE
 */
// Decorador concreto para compressão de dados.
public class CompressionDecorator extends DataSourceDecorator {

    public CompressionDecorator(DataSource source) {
        super(source);
    }

    @Override
    public void writeData(String data) {
        String compressedData = compress(data);
        wrappee.writeData(compressedData);
    }

    @Override
    public String readData() {
        String data = wrappee.readData();
        return decompress(data);
    }

    private String compress(String data) {
        System.out.println("Compressing data...");
        return "compressed(" + data + ")";
    }

    private String decompress(String data) {
        System.out.println("Decompressing data...");
        return data.replace("compressed(", "").replace(")", "");
    }
}
